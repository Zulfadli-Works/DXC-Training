package com.controller;

import java.io.IOException;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.ModelBank;

import java.util.Properties;
import java.util.Random;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 * Servlet implementation class DepositBank
 */
@WebServlet("/TransferBankWithEmail")
public class TransferBankWithEmail extends HttpServlet {
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Integer.parseInt(req.getParameter("amount"));  
		int amount = Integer.parseInt(req.getParameter("amount"));
		
		Integer.parseInt(req.getParameter("amount"));  
		int toAccNo = Integer.parseInt(req.getParameter("toAccNo"));
		
		ModelBank mb = new ModelBank();
		HttpSession session = req.getSession();
		String un = (String) session.getAttribute("un");
		mb.setUn(un);
//		System.out.println(un);
		int accNo = (int) session.getAttribute("accNo");
		mb.setAccNo(accNo);
		
		mb.setAmount(amount);
		mb.setToAccNo(toAccNo);
		
		
		int x = mb.transfer();
//		System.out.println("TEST");
		if (x == 0)
		{
			//unsuccessful retrieval of balance
		}
		else
		{
			
			session.setAttribute("amount", amount);
			//login successful
			double balance = mb.getBalance();
			
			String toEmail = (String) session.getAttribute("email");
			System.out.println("Test");
//			System.out.println(toEmail);
			String name = (String) session.getAttribute("name");
			
			String fromEmail = Credentials.email; //sender's mail id.
			String pwd = Credentials.pwd;		//sender's mail pwd.
//			String toEmail="";  //reciever's mail id.
			
			String subject="DO NOT REPLY: Mail from Java Program"; // mail subject line
			String msg="Hi " + name + ", You have transfered to account number: " + toAccNo + ", $" + amount; //mail body
			
			session.setAttribute("email", toEmail);
			
			//Creating Session Object
			Properties prop = new Properties();
			prop.put("mail.smtp.host", "smtp.gmail.com");
			prop.put("mail.smtp.port", 587);
			prop.put("mail.smtp.auth", "true");
			prop.put("mail.smtp.starttls.enable", "true");	//This enables the encryption

			Session session3 = Session.getDefaultInstance(prop, new javax.mail.Authenticator()
			{
				protected PasswordAuthentication getPasswordAuthentication()
				{
					//sender's mail id and pwd is encapsulated inside "SendersCredentials.java"
					return new PasswordAuthentication(fromEmail, pwd);
				}
			});

			try {
				//Composing the Mail
				MimeMessage mesg = new MimeMessage(session3);
				mesg.setFrom(new InternetAddress(fromEmail));
				mesg.addRecipient(Message.RecipientType.TO,new InternetAddress(toEmail));
				mesg.setSubject(subject);  
				mesg.setText(msg);  
				
				//Sending the Mail
				Transport.send(mesg);
				System.out.println("Mail Sent!!");
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			
			
		
			session.setAttribute("accNo", accNo);
			session.setAttribute("balance", balance);
			resp.sendRedirect("/BankingMVC/checkBalance.jsp");
		}
	}
}
