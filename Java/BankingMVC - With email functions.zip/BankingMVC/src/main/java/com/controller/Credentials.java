package com.controller;

public class Credentials 
{
	//You will need an email with 2FA turned off
	//on your email account, need to enable the allow less secure app access settings
	//need to enter real gmail address and password
	static String email="";
	static String pwd="";
}
